# creating a new file if it is does not exist
f = open("sample3.txt", "w")