# C_Programs showing operations using Assignment Operators,
#assignment operators in python are: =,+=,-=,*=,/=,%=,//=,**=,&=,|=,^=,>>=,<<=

#1- "="
x1 = 5
print("value of x1==>",x1)

#2- "+="
x2 = 10
x2 += 4
print("value of x2==>",x2)

#3- "-="
x3 = 10
x3 -= 4
print("value of x3==>",x3)

#4- "*="
x4 = 10
x4 *= 4
print("value of x4==>",x4)

#5- "/="
x5 = 10
x5 /= 4
print("value of x5==>",x5)

#6- "%="
x6 = 10
x6 %= 4
print("value of x6==>",x6)

#7- "//="
x7 = 10
x7 //= 4
print("value of x7==>",x7)

#8- "**="
x8 = 10
x8 **= 4
print("value of x8==>",x8)

#9- "&="
x9 = 10
x9 &= 4
print("value of x9==>",x9)

#10- "|="
x10 = 10
x10 |= 4
print("value of x10==>",x10)

#11- "^="
x11 = 10
x11 ^= 4
print("value of x11==>",x11)

#12- ">>="
x12 = 10
x12 >>= 4
print("value of x12==>",x12)

#13- "<<="
x13 = 10
x13 <<= 4
print("value of x13==>",x13)
