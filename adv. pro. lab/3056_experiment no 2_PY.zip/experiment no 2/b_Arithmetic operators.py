from __future__ import division
# 1_b_arthemtic operators in python are 
# 1-addition(+)  2-subtraction(-)  3-multiplication(*)  4-division(/)  5-modulus(%)  6-exponention(**)  7-Floor division(//)

#addition
x1 = 10
y1 = 20
print("addition is==>",x1 + y1)

#subtraction
x2 = 50
y2 = 20
print("subtraction is==>",x2 - y2)

#multiplication
x3 = 10
y3 = 20
print("multiplication is==>",x3 * y3)

#division
x4 = 16
y4 = 4
print("division is==>",x4 / y4)

#modulus
x5 = 30
y5 = 12
print("reminder is==>",x5 % y5)

#exponention
x6 = 2
y6 = 3
print("2^3 is==>",x6**y6)

#floor division
x7 = 15
y7 = 2
print("results rounds to nearesr whole number==>",x7 // y7)#the floor division // rounds the result down to the nearest whole number