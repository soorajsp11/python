# E_logical operator in python
#logical oprators are: 1-AND 2-OR 3-NOT

# 1- AND
x1 = 15
print(x1 > 10 and x1 < 20)

# 2- OR
x = 15
print(x > 10 or x < 20)

# 3- NOT
x = 15
print(not(x > 10 and x < 20))
