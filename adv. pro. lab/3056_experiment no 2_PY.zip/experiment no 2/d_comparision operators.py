# Programs showing operations using Comparison Operators,
# compairision operators in python are: "==","!=",">","<",">=","<="

# 1- "=="
x1 = 10
y1 = 15
print(x1 == y1)# returns False because 5 is not equal to 3

# 2- "!="
x2 = 10
y2 = 15
print(x2 != y2)# returns False because 5 is not equal to 3

# 3- ">"
x3 = 10
y3 = 15
print(x3 > y3)

# 4- "<"
x4 = 10
y4 = 15
print(x4 < y4)

 # 5- ">="
x5 = 10
y5 = 15
print(x5 >= y5)

# 6- "<="
x6 = 10
y6 = 15
print(x6 <= y6)