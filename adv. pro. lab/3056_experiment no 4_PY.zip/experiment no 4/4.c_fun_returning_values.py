# 4.c_function returning values

def fun1(x):
    return 2 * x
print("5*2=",fun1(5))
print("7*2=",fun1(7))
print("8*2=",fun1(8))

def fun2(x):
    return x**2
print("square of 2 is:",fun2(2))
print("square of 3 is:",fun2(3))
print("square of 5 is:",fun2(5))

