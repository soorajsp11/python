i = 1
loop do
  puts "Message number #{i}"

  i = i + 1
  if i == 6
    break
  end
end