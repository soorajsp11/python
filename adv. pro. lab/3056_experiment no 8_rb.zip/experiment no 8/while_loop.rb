i = 1
while i <= 5 do
  puts "Message number #{i}"
  i = i + 1
end
