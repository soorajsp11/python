#for loop to print a statment multiple times
for i in 1..5 do
    puts "Message number #{i}"
  end

