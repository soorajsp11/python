i = 1
until i == 6 do
  puts "Message number #{i}"
  i = i + 1
end