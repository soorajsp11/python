#if
age = 26
if (age >= 18)
  puts "You are eligible to get your driver's license."
end 

# if-else
age = 19
if (age >= 18)
  puts "you can vote"
else
  puts "you are not eligible for vote"
end

#if-elseif-else
x = 1
if x > 2
   puts "x is greater than 2"
elsif x <= 2 and x!=0
   puts "x is 1"
else
   puts "value of x is",x
end