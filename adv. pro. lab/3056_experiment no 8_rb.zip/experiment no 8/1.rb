#This is single line comment
=begin
    this is multiline comment
    thi sis mulktiline comment
=end


puts ("hello world")
print("hello world1") #it prints on next line
puts("hello world2")